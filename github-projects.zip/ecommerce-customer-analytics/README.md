# E-commerce Customer Segmentation & Revenue Forecasting

Customer segmentation and 7-day-ahead revenue forecasting on 541,909 real transactions from a UK online retailer (Dec 2010 – Dec 2011), built in Python with pandas and scikit-learn.

**Key results**

- **16% of customers generate 64% of revenue.** K-means clustering on recency, frequency, and spend (RFM) splits 4,324 customers into four segments.
- **The segments predict future behavior.** When customers are segmented using only data before Sept 1, 2011, **94%** of "Champions" buy again over the next three months, compared with **40%** of "Dormant" customers.
- **The forecast cuts error by 16% versus a naive baseline.** A ridge regression model forecasts daily revenue 7 days ahead with a weighted absolute percentage error (WAPE) of **33.4%**, versus 40.0% for "same day last week." It is evaluated on four rolling backtest folds.
- **A data quality issue was found and fixed.** 2,307 sales were later fully reversed by cancellations, including a single 80,995-unit order worth about £168k. They were removed so they don't inflate revenue.

![Share of customers and revenue by segment](reports/figures/segment_shares.png)

---

## 1. Data and cleaning

The data is the [UCI Online Retail dataset](https://archive.ics.uci.edu/dataset/352/online+retail): every transaction from a UK-based online gift retailer whose customers are largely wholesalers. `run_all.py` downloads it automatically from a public GitHub mirror.

Each cleaning rule is applied in turn and its effect is logged. `validate()` then fails loudly if any assumption is broken.

| Step | Rows removed |
|---|---:|
| Missing customer ID | 135,080 |
| Cancellation rows | 8,905 |
| Sales fully reversed by a later cancellation (same customer, product, and quantity) | 2,307 |
| Non-positive quantity or price | 40 |
| Fees and adjustments (postage, bank charges, manual) | 1,502 |
| Exact duplicate rows | 5,152 |
| **Clean rows** | **388,923** (4,324 customers, 18,317 orders, £8.36M revenue) |

Removing only the cancellation rows is a common mistake, because the original sale stays in the data. Here, each cancellation is paired with at most one matching earlier sale. Partial cancellations leave the sale untouched, and a unit test covers that case.

## 2. Customer segmentation (RFM + k-means)

**Features.** For each customer:

- **Recency:** days since their last order
- **Frequency:** number of orders
- **Monetary:** total spend

All three are log-transformed, because they are heavily right-skewed, and then standardized.

**Choosing k.** k = 2 has the highest silhouette score (0.43), but it only separates active from inactive customers. k = 3 and k = 4 score almost the same (0.341 vs 0.339), so k = 4 was chosen because it gives more actionable segments. Scores for every k are in [`reports/k_selection.csv`](reports/k_selection.csv).

| Segment | Customers | Median days since last order | Median orders | Median spend | Share of revenue |
|---|---:|---:|---:|---:|---:|
| Champions | 682 | 8 | 10 | £3,700 | 64% |
| At-risk high value | 1,189 | 53 | 4 | £1,327 | 24% |
| New / low spend | 814 | 16 | 2 | £469 | 5% |
| Dormant | 1,639 | 173 | 1 | £290 | 7% |

Segment names are assigned by rule, based on each cluster's median recency and spend rank, so they stay correct if the data changes.

**Validation.** A useful segmentation should predict what customers do next. To test this, customers were segmented on data before Sept 1, 2011, and then their actual purchases over the following three months were measured:

![Return rate by segment](reports/figures/segment_forward_validation.png)

**What to do with it**

- **Champions:** protect with loyalty perks.
- **At-risk high value:** customers who spent well but have gone quiet for about two months. They are the clearest win-back target.
- **Dormant:** low-cost reactivation only.

## 3. Revenue forecasting (7 days ahead)

**Setup.** The target is daily revenue. Every feature uses data that is at least 7 days old, so each prediction could have been made a week in advance. A unit test checks that changing the last 7 days of data leaves those days' features unchanged.

**Features:**

- Same-weekday revenue lags (7, 14, 21, and 28 days)
- Trailing averages
- Lagged order counts, which are steadier than revenue
- Revenue lags with spikes capped at the trailing 95th percentile
- Calendar features and a trend term

**Evaluation.** A rolling-origin backtest over four 28-day folds (Aug 20 – Dec 9, 2011). Each fold trains only on data before it. WAPE is measured on open days, since the store takes no orders on Saturdays.

| Model | Mean WAPE | Mean absolute error (£/day) |
|---|---:|---:|
| **Ridge regression** | **33.4%** | **12,119** |
| 4-week same-weekday average (baseline) | 34.8% | 12,366 |
| Gradient boosting | 36.2% | 12,951 |
| Seasonal naive: same day last week (baseline) | 40.0% | 14,284 |

![Forecast vs actual, final fold](reports/figures/forecast.png)

**Honest read.** Ridge regression beats the naive baseline by 16%, but beats a well-chosen 4-week average by only about 4%. It also loses to that average in one of the four folds. Daily revenue here is driven by large, irregular wholesale orders, and history alone can't predict those. Gradient boosting overfit on only about 300 training days.

Likely improvements:

- Forecast weekly totals, which is what is usually planned against.
- Model order count and order size separately.
- Add more than one year of history, so seasonality can be learned.

## How to run

```bash
pip install -r requirements.txt
python run_all.py      # downloads data, writes reports/ and reports/figures/
python -m pytest -q    # 6 unit tests on small hand-built data
```

## Project structure

```
src/data.py           load, clean, validate
src/segmentation.py   RFM, k selection, k-means, segment naming, forward validation
src/forecasting.py    leak-free features, baselines, models, rolling backtest
src/plots.py          report figures
run_all.py            end-to-end pipeline
tests/                unit tests (cleaning rules, RFM, naming, no-leakage)
reports/              metrics.json, CSV outputs, figures
```

Built with AI-assisted development (Claude). Every number above is reproduced by `run_all.py` and checked by the tests.

*Data: Daqing Chen, "Online Retail," UCI Machine Learning Repository, 2015 (CC BY 4.0).*
