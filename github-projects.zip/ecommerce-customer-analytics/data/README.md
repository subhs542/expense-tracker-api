The raw CSV (about 45 MB) is downloaded here automatically by run_all.py and is not committed.
