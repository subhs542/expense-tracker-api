"""Run the full analysis: clean data, segment customers, backtest forecasts, write reports.

Usage:  python run_all.py
"""

import json
from pathlib import Path

import pandas as pd

from src import forecasting, plots, segmentation
from src.data import clean, load_raw

REPORTS = Path(__file__).parent / "reports"
FIGURES = REPORTS / "figures"
K = 4
VALIDATION_CUTOFF = "2011-09-01"


def main() -> None:
    FIGURES.mkdir(parents=True, exist_ok=True)

    df, cleaning = clean(load_raw())
    print("Cleaning:", cleaning.as_dict())

    # Customer segmentation
    as_of = df["InvoiceDate"].max().normalize() + pd.Timedelta(days=1)
    rfm = segmentation.rfm_table(df, as_of)
    X, _ = segmentation.scale(rfm)
    k_scores = segmentation.choose_k(X)
    _, seg_summary, _ = segmentation.segment(rfm, K)
    fwd = segmentation.forward_validation(df, pd.Timestamp(VALIDATION_CUTOFF), K)

    # Forecasting
    daily = forecasting.daily_series(df)
    fc_summary, fc_folds, fc_preds = forecasting.backtest(daily)

    # Reports
    k_scores.round(4).to_csv(REPORTS / "k_selection.csv", index=False)
    seg_summary.round(4).to_csv(REPORTS / "segments.csv")
    fwd.round(4).to_csv(REPORTS / "segment_forward_validation.csv")
    fc_summary.round(4).to_csv(REPORTS / "forecast_backtest_summary.csv")
    fc_folds.round(4).to_csv(REPORTS / "forecast_backtest_folds.csv", index=False)

    best = fc_summary.index[0]
    naive = "Seasonal naive (same day last week)"
    metrics = {
        "cleaning": cleaning.as_dict(),
        "segmentation": {
            "k": K,
            "silhouette": round(float(k_scores.set_index("k").loc[K, "silhouette"]), 3),
            "segments": seg_summary.round(4).reset_index().to_dict(orient="records"),
            "forward_validation_cutoff": VALIDATION_CUTOFF,
            "forward_validation": fwd.round(4).reset_index().to_dict(orient="records"),
        },
        "forecasting": {
            "best_model": best,
            "best_wape": round(float(fc_summary.loc[best, "WAPE"]), 4),
            "wape_reduction_vs_seasonal_naive": round(
                1 - float(fc_summary.loc[best, "WAPE"] / fc_summary.loc[naive, "WAPE"]), 4),
            "summary": fc_summary.round(4).reset_index().to_dict(orient="records"),
        },
    }
    (REPORTS / "metrics.json").write_text(json.dumps(metrics, indent=2, default=str))

    plots.segment_shares(seg_summary, FIGURES / "segment_shares.png")
    plots.forward_validation(fwd, VALIDATION_CUTOFF, FIGURES / "segment_forward_validation.png")
    plots.forecast(fc_preds, [best, "4-week same-weekday average"], FIGURES / "forecast.png")

    print("\nSegments:\n", seg_summary.round(2).to_string())
    print("\nForward validation:\n", fwd.round(3).to_string())
    print("\nForecast backtest (mean over folds):\n", fc_summary.round(3).to_string())


if __name__ == "__main__":
    main()
