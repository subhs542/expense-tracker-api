"""Load, clean, and validate the UCI Online Retail transaction data."""

from __future__ import annotations

import urllib.request
from dataclasses import dataclass, asdict
from pathlib import Path

import pandas as pd

DATA_URL = (
    "https://raw.githubusercontent.com/databricks/Spark-The-Definitive-Guide/"
    "master/data/retail-data/all/online-retail-dataset.csv"
)
DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "online-retail.csv"


def download(path: Path = DATA_PATH) -> Path:
    """Download the raw CSV (about 45 MB) if it is not already on disk."""
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        print(f"Downloading dataset to {path} ...")
        urllib.request.urlretrieve(DATA_URL, path)
    return path


def load_raw(path: Path = DATA_PATH) -> pd.DataFrame:
    download(path)
    df = pd.read_csv(
        path,
        dtype={"InvoiceNo": str, "StockCode": str, "CustomerID": "Int64"},
        encoding="utf-8",
    )
    df["InvoiceDate"] = pd.to_datetime(df["InvoiceDate"], format="%m/%d/%Y %H:%M")
    return df


@dataclass
class CleaningReport:
    raw_rows: int
    missing_customer: int
    cancellations: int
    reversed_sales: int
    non_positive_qty_or_price: int
    non_product_codes: int
    duplicates: int
    clean_rows: int
    customers: int
    invoices: int
    revenue: float

    def as_dict(self) -> dict:
        return asdict(self)


# Stock codes that are fees or adjustments rather than products sold.
NON_PRODUCT_CODES = {"POST", "D", "C2", "M", "BANK CHARGES", "PADS", "DOT", "CRUK", "AMAZONFEE", "S", "B"}


def clean(df: pd.DataFrame) -> tuple[pd.DataFrame, CleaningReport]:
    """Apply each cleaning rule in turn and record how many rows it removed."""
    raw_rows = len(df)

    missing = df["CustomerID"].isna()
    df = df[~missing]

    cancel = df["InvoiceNo"].str.startswith("C")
    # A cancellation only removes its own row; the original sale it reverses would
    # still count as revenue. Pair each cancellation with one matching earlier sale.
    reversed_sales = _reversed_sales(df, cancel)
    df = df[~cancel & ~reversed_sales]

    bad_values = (df["Quantity"] <= 0) | (df["UnitPrice"] <= 0)
    df = df[~bad_values]

    non_product = df["StockCode"].str.upper().isin(NON_PRODUCT_CODES)
    df = df[~non_product]

    dupes = df.duplicated()
    df = df[~dupes].copy()

    df["CustomerID"] = df["CustomerID"].astype(int)
    df["Revenue"] = df["Quantity"] * df["UnitPrice"]

    report = CleaningReport(
        raw_rows=raw_rows,
        missing_customer=int(missing.sum()),
        cancellations=int(cancel.sum()),
        reversed_sales=int(reversed_sales.sum()),
        non_positive_qty_or_price=int(bad_values.sum()),
        non_product_codes=int(non_product.sum()),
        duplicates=int(dupes.sum()),
        clean_rows=len(df),
        customers=int(df["CustomerID"].nunique()),
        invoices=int(df["InvoiceNo"].nunique()),
        revenue=round(float(df["Revenue"].sum()), 2),
    )
    validate(df)
    return df, report


def _reversed_sales(df: pd.DataFrame, cancel: pd.Series) -> pd.Series:
    """Flag sales that a cancellation fully reverses: same customer, product and
    quantity, placed before the cancellation. Each cancellation removes at most one
    sale, so partial or unmatched cancellations leave sales untouched."""
    key = ["CustomerID", "StockCode", "AbsQty"]
    work = df.assign(AbsQty=df["Quantity"].abs())
    sales = work[~cancel & (work["Quantity"] > 0)].sort_values("InvoiceDate", ascending=False)
    cancels = work[cancel & (work["Quantity"] < 0)].sort_values("InvoiceDate", ascending=False)

    sales = sales.assign(n=sales.groupby(key).cumcount())
    cancels = cancels.assign(n=cancels.groupby(key).cumcount())
    pairs = sales.reset_index().merge(
        cancels[key + ["n", "InvoiceDate"]], on=key + ["n"], suffixes=("", "_cancel")
    )
    pairs = pairs[pairs["InvoiceDate"] <= pairs["InvoiceDate_cancel"]]
    return df.index.isin(pairs["index"])


def validate(df: pd.DataFrame) -> None:
    """Fail loudly if the cleaned data breaks an assumption the analysis relies on."""
    assert df["CustomerID"].notna().all(), "missing customer IDs remain"
    assert (df["Quantity"] > 0).all(), "non-positive quantities remain"
    assert (df["UnitPrice"] > 0).all(), "non-positive prices remain"
    assert not df["InvoiceNo"].str.startswith("C").any(), "cancellations remain"
    assert not df.duplicated().any(), "duplicate rows remain"
    assert (df["Revenue"] > 0).all(), "non-positive revenue lines remain"
