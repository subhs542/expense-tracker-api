"""Daily revenue forecasting, 7 days ahead, evaluated with a rolling-origin backtest.

Every feature uses data at least 7 days old, so each prediction could have been made
a week in advance. Models are compared against two simple baselines; a model is only
useful if it beats them.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

HORIZON = 7          # days ahead
LAGS = [7, 14, 21, 28]
CLOSED_DOW = 5        # the store takes no orders on Saturdays


def daily_series(df: pd.DataFrame) -> pd.DataFrame:
    """Daily revenue and order counts, with closed days filled as zero."""
    daily = df.set_index("InvoiceDate").resample("D").agg(
        {"Revenue": "sum", "InvoiceNo": "nunique"}
    ).rename(columns={"InvoiceNo": "Orders"})
    return daily.asfreq("D", fill_value=0)


def make_features(daily: pd.DataFrame) -> pd.DataFrame:
    y, orders = daily["Revenue"], daily["Orders"]
    X = pd.DataFrame(index=y.index)
    for lag in LAGS:
        X[f"lag_{lag}"] = y.shift(lag)
    X["same_weekday_mean_4w"] = X[[f"lag_{l}" for l in LAGS]].mean(axis=1)
    X["mean_7d_ending_7d_ago"] = y.shift(HORIZON).rolling(7).mean()
    X["mean_28d_ending_7d_ago"] = y.shift(HORIZON).rolling(28).mean()

    # Order counts are steadier than revenue, which large wholesale orders dominate.
    for lag in LAGS:
        X[f"orders_lag_{lag}"] = orders.shift(lag)
    X["orders_mean_7d_ending_7d_ago"] = orders.shift(HORIZON).rolling(7).mean()

    # Revenue lags with spikes capped at the trailing 95th percentile.
    cap = y.rolling(56, min_periods=14).quantile(0.95).shift(HORIZON)
    capped = np.minimum(y, cap)
    for lag in LAGS:
        X[f"capped_lag_{lag}"] = capped.shift(lag)

    X["dayofweek"] = y.index.dayofweek
    X["dayofmonth"] = y.index.day
    X["month"] = y.index.month
    X["trend"] = np.arange(len(y))
    return X


def baseline_seasonal_naive(X: pd.DataFrame) -> np.ndarray:
    return X["lag_7"].to_numpy()


def baseline_weekday_mean(X: pd.DataFrame) -> np.ndarray:
    return X["same_weekday_mean_4w"].to_numpy()


MODELS = {
    "Seasonal naive (same day last week)": None,
    "4-week same-weekday average": None,
    "Ridge regression": lambda: make_pipeline(StandardScaler(), Ridge(alpha=10.0)),
    "Gradient boosting": lambda: HistGradientBoostingRegressor(
        max_iter=300, learning_rate=0.05, max_leaf_nodes=15,
        min_samples_leaf=10, l2_regularization=1.0, random_state=42,
    ),
}


def _predict(name, model_factory, X_train, y_train, X_test):
    if name.startswith("Seasonal naive"):
        return baseline_seasonal_naive(X_test)
    if name.startswith("4-week"):
        return baseline_weekday_mean(X_test)
    model = model_factory()
    model.fit(X_train, y_train)
    return np.clip(model.predict(X_test), 0, None)


def backtest(daily: pd.DataFrame, n_folds: int = 4, fold_days: int = 28):
    """Rolling-origin evaluation: train on everything before each fold, test on the fold."""
    X = make_features(daily)
    y = daily["Revenue"]
    valid = X.notna().all(axis=1)
    X, y = X[valid], y[valid]

    rows, predictions = [], []
    for fold in range(n_folds, 0, -1):
        test_end = len(y) - (fold - 1) * fold_days
        test_start = test_end - fold_days
        X_tr, y_tr = X.iloc[:test_start], y.iloc[:test_start]
        X_te, y_te = X.iloc[test_start:test_end], y.iloc[test_start:test_end]
        open_days = X_te["dayofweek"] != CLOSED_DOW

        for name, factory in MODELS.items():
            pred = _predict(name, factory, X_tr, y_tr, X_te)
            pred = np.where(open_days, pred, 0.0)
            err = np.abs(y_te.to_numpy() - pred)[open_days]
            actual = y_te.to_numpy()[open_days]
            rows.append({
                "fold_start": y_te.index[0].date(),
                "fold_end": y_te.index[-1].date(),
                "model": name,
                "MAE": err.mean(),
                "WAPE": err.sum() / actual.sum(),
            })
            predictions.append(pd.DataFrame({
                "date": y_te.index, "model": name, "actual": y_te.to_numpy(), "predicted": pred,
            }))

    folds = pd.DataFrame(rows)
    summary = (folds.groupby("model")[["MAE", "WAPE"]].mean()
               .sort_values("WAPE"))
    return summary, folds, pd.concat(predictions, ignore_index=True)
