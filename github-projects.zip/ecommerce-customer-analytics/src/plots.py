"""Report figures. Colors are a fixed, colorblind-validated categorical order."""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd

SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK_2 = "#52514e"
GRID = "#e4e3df"
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"


def _style(ax, title, subtitle=None):
    fig = ax.figure
    fig.patch.set_facecolor(SURFACE)
    ax.set_facecolor(SURFACE)
    for side in ("top", "right", "left"):
        ax.spines[side].set_visible(False)
    ax.spines["bottom"].set_color(GRID)
    ax.tick_params(colors=INK_2, labelsize=9, length=0)
    ax.grid(axis="x" if ax.get_label() == "hbar" else "y", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    fig.text(0.02, 0.97, title, fontsize=13, fontweight="bold", color=INK, va="top")
    if subtitle:
        fig.text(0.02, 0.91, subtitle, fontsize=9.5, color=INK_2, va="top")


def segment_shares(summary: pd.DataFrame, path: Path) -> None:
    order = summary.sort_values("ShareOfRevenue")
    y = np.arange(len(order))
    h = 0.36
    fig, ax = plt.subplots(figsize=(8, 4.2), dpi=200)
    ax.set_label("hbar")
    ax.barh(y + h / 2 + 0.01, order["ShareOfCustomers"], height=h, color=BLUE, label="Share of customers")
    ax.barh(y - h / 2 - 0.01, order["ShareOfRevenue"], height=h, color=ORANGE, label="Share of revenue")
    for i, (c, r) in enumerate(zip(order["ShareOfCustomers"], order["ShareOfRevenue"])):
        ax.text(c + 0.008, i + h / 2, f"{c:.0%}", va="center", fontsize=8.5, color=INK_2)
        ax.text(r + 0.008, i - h / 2, f"{r:.0%}", va="center", fontsize=8.5, color=INK_2)
    ax.set_yticks(y, order.index, color=INK, fontsize=10)
    ax.xaxis.set_major_formatter(mticker.PercentFormatter(1.0, decimals=0))
    ax.set_xlim(0, max(order["ShareOfRevenue"].max(), order["ShareOfCustomers"].max()) * 1.15)
    _style(ax, "16% of customers drive 64% of revenue",
           "Share of customers and revenue by k-means RFM segment, Dec 2010 – Dec 2011")
    ax.legend(loc="lower right", frameon=False, fontsize=9, labelcolor=INK_2)
    fig.subplots_adjust(left=0.22, right=0.97, top=0.82, bottom=0.1)
    fig.savefig(path, facecolor=SURFACE)
    plt.close(fig)


def forward_validation(result: pd.DataFrame, cutoff: str, path: Path) -> None:
    order = result.sort_values("ReturnRate")
    fig, ax = plt.subplots(figsize=(8, 3.6), dpi=200)
    ax.set_label("hbar")
    ax.barh(order.index, order["ReturnRate"], height=0.5, color=BLUE)
    for i, (rate, spend) in enumerate(zip(order["ReturnRate"], order["AvgFutureSpend"])):
        ax.text(rate + 0.01, i, f"{rate:.0%} returned · avg £{spend:,.0f} spent",
                va="center", fontsize=8.5, color=INK_2)
    ax.xaxis.set_major_formatter(mticker.PercentFormatter(1.0, decimals=0))
    ax.set_xlim(0, 1.5)
    ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.tick_params(axis="y", labelcolor=INK, labelsize=10)
    _style(ax, "Segments predict who comes back",
           f"Segmented on data before {cutoff}; share of each segment that purchased afterward")
    fig.subplots_adjust(left=0.22, right=0.97, top=0.8, bottom=0.12)
    fig.savefig(path, facecolor=SURFACE)
    plt.close(fig)


def forecast(preds: pd.DataFrame, models: list[str], path: Path) -> None:
    last_start = preds["date"].max() - pd.Timedelta(days=27)
    p = preds[preds["date"] >= last_start]
    fig, ax = plt.subplots(figsize=(9, 4.2), dpi=200)
    actual = p[p["model"] == models[0]].set_index("date")["actual"]
    ax.plot(actual.index, actual / 1000, color=INK, linewidth=2, label="Actual")
    for model, color in zip(models, [BLUE, ORANGE]):
        s = p[p["model"] == model].set_index("date")["predicted"]
        ax.plot(s.index, s / 1000, color=color, linewidth=2, label=model)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"£{v:,.0f}k"))
    ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter("%b %d"))
    _style(ax, "7-day-ahead daily revenue forecast, final backtest fold",
           "Saturdays are closed (zero revenue). Forecasts use only data at least 7 days old.")
    ax.legend(loc="upper left", frameon=False, fontsize=9, labelcolor=INK_2, ncol=3)
    fig.subplots_adjust(left=0.08, right=0.98, top=0.82, bottom=0.1)
    fig.savefig(path, facecolor=SURFACE)
    plt.close(fig)
