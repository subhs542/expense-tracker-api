"""RFM customer segmentation with k-means, plus a forward-looking check that the
segments actually predict who buys next."""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

RANDOM_STATE = 42
FEATURES = ["Recency", "Frequency", "Monetary"]


def rfm_table(df: pd.DataFrame, as_of: pd.Timestamp) -> pd.DataFrame:
    """Recency (days since last order), Frequency (orders), Monetary (total spend)."""
    df = df[df["InvoiceDate"] < as_of]
    rfm = df.groupby("CustomerID").agg(
        LastPurchase=("InvoiceDate", "max"),
        Frequency=("InvoiceNo", "nunique"),
        Monetary=("Revenue", "sum"),
    )
    rfm["Recency"] = (as_of - rfm["LastPurchase"]).dt.days
    return rfm[FEATURES]


def scale(rfm: pd.DataFrame) -> tuple[np.ndarray, StandardScaler]:
    """RFM values are heavily right-skewed, so log-transform before standardizing."""
    scaler = StandardScaler()
    X = scaler.fit_transform(np.log1p(rfm[FEATURES]))
    return X, scaler


def choose_k(X: np.ndarray, k_range=range(2, 9)) -> pd.DataFrame:
    rows = []
    for k in k_range:
        km = KMeans(n_clusters=k, n_init=20, random_state=RANDOM_STATE).fit(X)
        rows.append({
            "k": k,
            "inertia": km.inertia_,
            "silhouette": silhouette_score(X, km.labels_, sample_size=3000, random_state=RANDOM_STATE),
        })
    return pd.DataFrame(rows)


def name_segments(profile: pd.DataFrame) -> dict[int, str]:
    """Name clusters from their median recency and spend relative to all customers.

    Ranking (rather than fixed thresholds) keeps names stable if the data changes.
    """
    order_value = profile["Monetary"].rank()
    order_recent = (-profile["Recency"]).rank()
    k = len(profile)
    names = {}
    for cid in profile.index:
        high_value = order_value[cid] > k / 2
        recent = order_recent[cid] > k / 2
        if high_value and recent:
            names[cid] = "Champions"
        elif high_value and not recent:
            names[cid] = "At-risk high value"
        elif recent:
            names[cid] = "New / low spend"
        else:
            names[cid] = "Dormant"
    # If two clusters land in the same quadrant, rank them by spend and number them.
    counts = pd.Series(names).value_counts()
    for name in counts[counts > 1].index:
        ids = [c for c in names if names[c] == name]
        for i, cid in enumerate(sorted(ids, key=lambda c: -profile.loc[c, "Monetary"]), 1):
            names[cid] = f"{name} ({i})"
    return names


def segment(rfm: pd.DataFrame, k: int) -> tuple[pd.DataFrame, pd.DataFrame, KMeans]:
    X, _ = scale(rfm)
    km = KMeans(n_clusters=k, n_init=20, random_state=RANDOM_STATE).fit(X)
    out = rfm.copy()
    out["Cluster"] = km.labels_
    profile = out.groupby("Cluster")[FEATURES].median()
    names = name_segments(profile)
    out["Segment"] = out["Cluster"].map(names)

    summary = out.groupby("Segment").agg(
        Customers=("Recency", "size"),
        MedianRecencyDays=("Recency", "median"),
        MedianOrders=("Frequency", "median"),
        MedianSpend=("Monetary", "median"),
        TotalSpend=("Monetary", "sum"),
    )
    summary["ShareOfCustomers"] = summary["Customers"] / summary["Customers"].sum()
    summary["ShareOfRevenue"] = summary["TotalSpend"] / summary["TotalSpend"].sum()
    summary = summary.sort_values("MedianSpend", ascending=False)
    return out, summary, km


def forward_validation(df: pd.DataFrame, cutoff: pd.Timestamp, k: int) -> pd.DataFrame:
    """Segment customers on data before `cutoff`, then measure what each segment
    actually did after it. Good segments should separate future behavior."""
    rfm = rfm_table(df, as_of=cutoff)
    seg, _, _ = segment(rfm, k)
    future = df[df["InvoiceDate"] >= cutoff].groupby("CustomerID")["Revenue"].sum()
    seg["FutureSpend"] = future.reindex(seg.index).fillna(0.0)
    seg["Returned"] = seg["FutureSpend"] > 0
    result = seg.groupby("Segment").agg(
        Customers=("Returned", "size"),
        ReturnRate=("Returned", "mean"),
        AvgFutureSpend=("FutureSpend", "mean"),
    )
    return result.sort_values("AvgFutureSpend", ascending=False)
