"""Unit tests on small hand-built data, so they run in seconds without the full dataset."""

import numpy as np
import pandas as pd

from src.data import clean
from src.forecasting import HORIZON, daily_series, make_features
from src.segmentation import name_segments, rfm_table


def _tx(rows):
    df = pd.DataFrame(rows, columns=["InvoiceNo", "StockCode", "Description", "Quantity",
                                     "InvoiceDate", "UnitPrice", "CustomerID", "Country"])
    df["InvoiceDate"] = pd.to_datetime(df["InvoiceDate"])
    df["CustomerID"] = df["CustomerID"].astype("Int64")
    return df


def test_clean_removes_bad_rows_and_reversed_sales():
    df = _tx([
        ["1", "A", "x", 2, "2011-01-01", 5.0, 10, "UK"],       # kept
        ["2", "B", "x", 100, "2011-01-02", 1.0, 11, "UK"],     # reversed by C3
        ["C3", "B", "x", -100, "2011-01-03", 1.0, 11, "UK"],   # cancellation
        ["4", "A", "x", 1, "2011-01-04", 5.0, None, "UK"],     # no customer
        ["5", "POST", "x", 1, "2011-01-05", 18.0, 10, "UK"],   # postage fee
        ["6", "A", "x", 1, "2011-01-06", 0.0, 10, "UK"],       # zero price
        ["1", "A", "x", 2, "2011-01-01", 5.0, 10, "UK"],       # exact duplicate
    ])
    out, report = clean(df)
    assert list(out["InvoiceNo"]) == ["1"]
    assert report.reversed_sales == 1
    assert report.revenue == 10.0


def test_partial_cancellation_keeps_original_sale():
    df = _tx([
        ["1", "A", "x", 10, "2011-01-01", 1.0, 10, "UK"],
        ["C2", "A", "x", -4, "2011-01-02", 1.0, 10, "UK"],
    ])
    out, report = clean(df)
    assert report.reversed_sales == 0
    assert len(out) == 1


def test_rfm_values():
    df = _tx([
        ["1", "A", "x", 1, "2011-01-01", 10.0, 1, "UK"],
        ["2", "A", "x", 1, "2011-01-08", 10.0, 1, "UK"],
        ["3", "A", "x", 3, "2011-01-05", 10.0, 2, "UK"],
    ])
    df["Revenue"] = df["Quantity"] * df["UnitPrice"]
    rfm = rfm_table(df, as_of=pd.Timestamp("2011-01-10"))
    assert rfm.loc[1].tolist() == [2, 2, 20.0]
    assert rfm.loc[2].tolist() == [5, 1, 30.0]


def test_segment_names_cover_quadrants():
    profile = pd.DataFrame(
        {"Recency": [5, 100, 10, 200], "Frequency": [10, 5, 2, 1], "Monetary": [5000, 2000, 300, 200]},
        index=[0, 1, 2, 3],
    )
    names = name_segments(profile)
    assert names == {0: "Champions", 1: "At-risk high value", 2: "New / low spend", 3: "Dormant"}


def test_features_do_not_leak_recent_data():
    """Changing the last 7 days of revenue must not change any feature for those days."""
    dates = pd.date_range("2011-01-01", periods=80, freq="D")
    rng = np.random.default_rng(0)
    daily = pd.DataFrame({"Revenue": rng.uniform(100, 200, 80), "Orders": rng.integers(5, 20, 80)}, index=dates)
    altered = daily.copy()
    altered.iloc[-HORIZON:] *= 10
    a, b = make_features(daily).iloc[-HORIZON:], make_features(altered).iloc[-HORIZON:]
    pd.testing.assert_frame_equal(a, b)


def test_daily_series_fills_closed_days():
    df = _tx([
        ["1", "A", "x", 1, "2011-01-03 10:00", 10.0, 1, "UK"],
        ["2", "A", "x", 1, "2011-01-05 10:00", 10.0, 1, "UK"],
    ])
    df["Revenue"] = df["Quantity"] * df["UnitPrice"]
    daily = daily_series(df)
    assert daily["Revenue"].tolist() == [10.0, 0.0, 10.0]
    assert daily["Orders"].tolist() == [1, 0, 1]
