# Expense Tracker API

A REST API for tracking personal expenses against monthly budgets, built with Python and FastAPI. It records spending by category and reports **budget-to-actual variance**: how much each category is over or under its budget, and whether it's on track.

![tests](https://github.com/YOUR-USERNAME/expense-tracker-api/actions/workflows/ci.yml/badge.svg)

## Features

- **Create, read, filter, and delete expenses** (`/expenses`), filtering by month and category.
- **Set monthly budgets** per category (`/budgets/{category}`).
- **Monthly summary** (`/summary/{YYYY-MM}`) with actual vs. budget, variance in dollars and percent, and an `over` / `under` / `on track` status per category.
- **Input validation**: negative amounts, unknown categories, bad dates, and invalid months are rejected with clear `422` errors.
- **Interactive API docs** generated automatically at `/docs`.

## Example

```bash
curl -X PUT localhost:8000/budgets/food -H 'content-type: application/json' -d '{"monthly_limit": 400}'
curl -X POST localhost:8000/expenses -H 'content-type: application/json' \
     -d '{"amount": 450, "category": "food", "spent_on": "2026-11-05", "note": "groceries"}'
curl localhost:8000/summary/2026-11
```

```json
{"month": "2026-11", "total_budget": 400.0, "total_actual": 450.0, "total_variance": 50.0,
 "categories": [{"category": "food", "budget": 400.0, "actual": 450.0,
                 "variance": 50.0, "variance_pct": 0.125, "status": "over"}]}
```

## Design

The code is split into layers, each with one job:

| File | Responsibility |
|---|---|
| `app/schemas.py` | Request and response models (Pydantic validates every request) |
| `app/repository.py` | Data access: all SQL lives in `ExpenseRepository` and `BudgetRepository` (SQLite) |
| `app/services.py` | Business logic: `BudgetService` computes budget-to-actual variance |
| `app/main.py` | REST endpoints (FastAPI) |
| `tests/test_api.py` | 6 tests covering CRUD, validation, filtering, and variance math |

Keeping SQL out of the endpoints and business logic out of the database layer means each part can be tested and changed on its own. For example, SQLite could be swapped for PostgreSQL by changing only the repository.

## Run it

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload        # then open http://localhost:8000/docs
python -m pytest -q                  # run the tests
```

With Docker:

```bash
docker build -t expense-tracker-api .
docker run -p 8000:8000 expense-tracker-api
```

Tests run automatically on every push through GitHub Actions (`.github/workflows/ci.yml`).

## Ideas for next steps

- Add user accounts and authentication
- Add recurring expenses and a CSV import
- Add a small React front end with charts

Built with AI-assisted development (Claude), then reviewed, tested, and run end to end.
