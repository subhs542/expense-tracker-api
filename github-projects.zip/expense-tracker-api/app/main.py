"""REST API for tracking expenses against monthly budgets.

Run locally:  uvicorn app.main:app --reload   (interactive docs at /docs)
"""

import os
import re

from fastapi import Depends, FastAPI, HTTPException, Query

from .repository import BudgetRepository, Database, ExpenseRepository
from .schemas import BudgetIn, Category, Expense, ExpenseIn, MonthlySummary
from .services import BudgetService

MONTH = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")


def create_app(db_path: str | None = None) -> FastAPI:
    db = Database(db_path or os.getenv("DB_PATH", "expenses.db"))
    expenses, budgets = ExpenseRepository(db), BudgetRepository(db)
    service = BudgetService(expenses, budgets)
    app = FastAPI(title="Expense Tracker API", version="1.0.0")

    def valid_month(month: str) -> str:
        if not MONTH.match(month):
            raise HTTPException(status_code=422, detail="month must be YYYY-MM")
        return month

    @app.get("/health")
    def health():
        return {"status": "ok"}

    @app.post("/expenses", response_model=Expense, status_code=201)
    def add_expense(item: ExpenseIn):
        return expenses.add(item)

    @app.get("/expenses", response_model=list[Expense])
    def list_expenses(month: str | None = Query(default=None), category: Category | None = None):
        if month:
            valid_month(month)
        return expenses.list(month=month, category=category)

    @app.get("/expenses/{expense_id}", response_model=Expense)
    def get_expense(expense_id: int):
        item = expenses.get(expense_id)
        if not item:
            raise HTTPException(status_code=404, detail="expense not found")
        return item

    @app.delete("/expenses/{expense_id}", status_code=204)
    def delete_expense(expense_id: int):
        if not expenses.delete(expense_id):
            raise HTTPException(status_code=404, detail="expense not found")

    @app.put("/budgets/{category}", status_code=204)
    def set_budget(category: Category, body: BudgetIn):
        budgets.set(category, body.monthly_limit)

    @app.get("/summary/{month}", response_model=MonthlySummary)
    def summary(month: str = Depends(valid_month)):
        return service.monthly_summary(month)

    return app


app = create_app()
