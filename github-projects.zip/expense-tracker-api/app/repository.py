"""Data access layer. All SQL lives here, so the rest of the app never touches the database directly."""

import sqlite3
from datetime import date

from .schemas import Expense, ExpenseIn


class Database:
    def __init__(self, path: str = ":memory:"):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                amount REAL NOT NULL CHECK (amount > 0),
                category TEXT NOT NULL,
                spent_on TEXT NOT NULL,
                note TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS budgets (
                category TEXT PRIMARY KEY,
                monthly_limit REAL NOT NULL CHECK (monthly_limit > 0)
            );
            """
        )


class ExpenseRepository:
    def __init__(self, db: Database):
        self.db = db

    def add(self, item: ExpenseIn) -> Expense:
        cur = self.db.conn.execute(
            "INSERT INTO expenses (amount, category, spent_on, note) VALUES (?, ?, ?, ?)",
            (item.amount, item.category, item.spent_on.isoformat(), item.note),
        )
        self.db.conn.commit()
        return Expense(id=cur.lastrowid, **item.model_dump())

    def get(self, expense_id: int) -> Expense | None:
        row = self.db.conn.execute("SELECT * FROM expenses WHERE id = ?", (expense_id,)).fetchone()
        return self._to_model(row) if row else None

    def list(self, month: str | None = None, category: str | None = None) -> list[Expense]:
        sql, args = "SELECT * FROM expenses WHERE 1=1", []
        if month:
            sql += " AND substr(spent_on, 1, 7) = ?"
            args.append(month)
        if category:
            sql += " AND category = ?"
            args.append(category)
        sql += " ORDER BY spent_on, id"
        return [self._to_model(r) for r in self.db.conn.execute(sql, args).fetchall()]

    def delete(self, expense_id: int) -> bool:
        cur = self.db.conn.execute("DELETE FROM expenses WHERE id = ?", (expense_id,))
        self.db.conn.commit()
        return cur.rowcount > 0

    def totals_by_category(self, month: str) -> dict[str, float]:
        rows = self.db.conn.execute(
            "SELECT category, SUM(amount) AS total FROM expenses "
            "WHERE substr(spent_on, 1, 7) = ? GROUP BY category",
            (month,),
        ).fetchall()
        return {r["category"]: r["total"] for r in rows}

    @staticmethod
    def _to_model(row: sqlite3.Row) -> Expense:
        return Expense(
            id=row["id"], amount=row["amount"], category=row["category"],
            spent_on=date.fromisoformat(row["spent_on"]), note=row["note"],
        )


class BudgetRepository:
    def __init__(self, db: Database):
        self.db = db

    def set(self, category: str, monthly_limit: float) -> None:
        self.db.conn.execute(
            "INSERT INTO budgets (category, monthly_limit) VALUES (?, ?) "
            "ON CONFLICT(category) DO UPDATE SET monthly_limit = excluded.monthly_limit",
            (category, monthly_limit),
        )
        self.db.conn.commit()

    def all(self) -> dict[str, float]:
        rows = self.db.conn.execute("SELECT category, monthly_limit FROM budgets").fetchall()
        return {r["category"]: r["monthly_limit"] for r in rows}
