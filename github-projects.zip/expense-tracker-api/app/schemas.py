"""Request and response models. Pydantic validates every request automatically."""

from datetime import date
from typing import Literal

from pydantic import BaseModel, Field

Category = Literal["housing", "food", "transport", "utilities", "health", "entertainment", "other"]


class ExpenseIn(BaseModel):
    amount: float = Field(gt=0, description="Amount in dollars; must be positive")
    category: Category
    spent_on: date
    note: str = Field(default="", max_length=200)


class Expense(ExpenseIn):
    id: int


class BudgetIn(BaseModel):
    monthly_limit: float = Field(gt=0)


class CategorySummary(BaseModel):
    category: str
    budget: float
    actual: float
    variance: float          # actual - budget; positive means overspent
    variance_pct: float      # variance / budget
    status: Literal["over", "under", "on track", "no budget"]


class MonthlySummary(BaseModel):
    month: str               # YYYY-MM
    total_budget: float
    total_actual: float
    total_variance: float
    categories: list[CategorySummary]
