"""Business logic: compare actual spending with budgets (budget-to-actual variance)."""

from .repository import BudgetRepository, ExpenseRepository
from .schemas import CategorySummary, MonthlySummary


class BudgetService:
    def __init__(self, expenses: ExpenseRepository, budgets: BudgetRepository, threshold: float = 0.05):
        self.expenses = expenses
        self.budgets = budgets
        self.threshold = threshold  # variance within +/- 5% counts as "on track"

    def monthly_summary(self, month: str) -> MonthlySummary:
        actuals = self.expenses.totals_by_category(month)
        budgets = self.budgets.all()
        rows = []
        for category in sorted(set(actuals) | set(budgets)):
            actual = round(actuals.get(category, 0.0), 2)
            budget = round(budgets.get(category, 0.0), 2)
            variance = round(actual - budget, 2)
            pct = round(variance / budget, 4) if budget else 0.0
            rows.append(CategorySummary(
                category=category, budget=budget, actual=actual,
                variance=variance, variance_pct=pct, status=self._status(budget, pct),
            ))
        total_budget = round(sum(r.budget for r in rows), 2)
        total_actual = round(sum(r.actual for r in rows), 2)
        return MonthlySummary(
            month=month, total_budget=total_budget, total_actual=total_actual,
            total_variance=round(total_actual - total_budget, 2), categories=rows,
        )

    def _status(self, budget: float, pct: float) -> str:
        if not budget:
            return "no budget"
        if pct > self.threshold:
            return "over"
        if pct < -self.threshold:
            return "under"
        return "on track"
