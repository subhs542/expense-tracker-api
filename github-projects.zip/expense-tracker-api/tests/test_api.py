import pytest
from fastapi.testclient import TestClient

from app.main import create_app


@pytest.fixture
def client():
    return TestClient(create_app(":memory:"))


def add(client, amount, category, day="2026-11-05", note=""):
    r = client.post("/expenses", json={"amount": amount, "category": category, "spent_on": day, "note": note})
    assert r.status_code == 201
    return r.json()


def test_create_and_get_expense(client):
    created = add(client, 42.5, "food", note="groceries")
    r = client.get(f"/expenses/{created['id']}")
    assert r.status_code == 200
    assert r.json()["amount"] == 42.5 and r.json()["note"] == "groceries"


def test_rejects_invalid_input(client):
    bad = [
        {"amount": -5, "category": "food", "spent_on": "2026-11-01"},      # negative amount
        {"amount": 5, "category": "crypto", "spent_on": "2026-11-01"},     # unknown category
        {"amount": 5, "category": "food", "spent_on": "not-a-date"},       # bad date
    ]
    for body in bad:
        assert client.post("/expenses", json=body).status_code == 422


def test_filter_by_month_and_category(client):
    add(client, 10, "food", "2026-10-31")
    add(client, 20, "food", "2026-11-01")
    add(client, 30, "transport", "2026-11-02")
    assert [e["amount"] for e in client.get("/expenses", params={"month": "2026-11"}).json()] == [20, 30]
    assert [e["amount"] for e in client.get("/expenses", params={"category": "food"}).json()] == [10, 20]
    assert client.get("/expenses", params={"month": "2026-13"}).status_code == 422


def test_delete_and_missing(client):
    created = add(client, 15, "health")
    assert client.delete(f"/expenses/{created['id']}").status_code == 204
    assert client.get(f"/expenses/{created['id']}").status_code == 404
    assert client.delete(f"/expenses/{created['id']}").status_code == 404


def test_budget_to_actual_summary(client):
    client.put("/budgets/food", json={"monthly_limit": 400})
    client.put("/budgets/transport", json={"monthly_limit": 100})
    client.put("/budgets/utilities", json={"monthly_limit": 200})
    add(client, 300, "food")
    add(client, 150, "food")          # food: 450 vs 400 -> +12.5%, over
    add(client, 98, "transport")      # transport: 98 vs 100 -> -2%, on track
    add(client, 60, "entertainment")  # no budget set
    s = client.get("/summary/2026-11").json()
    by = {c["category"]: c for c in s["categories"]}
    assert by["food"]["variance"] == 50 and by["food"]["variance_pct"] == 0.125 and by["food"]["status"] == "over"
    assert by["transport"]["status"] == "on track"
    assert by["utilities"]["actual"] == 0 and by["utilities"]["status"] == "under"
    assert by["entertainment"]["status"] == "no budget"
    assert s["total_budget"] == 700 and s["total_actual"] == 608 and s["total_variance"] == -92


def test_budget_update_overwrites(client):
    client.put("/budgets/food", json={"monthly_limit": 100})
    client.put("/budgets/food", json={"monthly_limit": 250})
    assert client.get("/summary/2026-11").json()["total_budget"] == 250
